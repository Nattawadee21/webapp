<!DOCTYPE html>
<html>
<head>
    <title>Dynamic Function Calls</title>
</head>
<body>
  <H2> Dynamic Function Calls </H2>
<?php
     function sayHello() {
       echo "Hello<br />";
     }
     $function_holder = "sayHello";
     $function_holder();
     sayHello();
   ?>
</body>
</html>