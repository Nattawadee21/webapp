<!DOCTYPE html>
<html>
<head>
    <title>Writing PHP Function which returns value</title>
</head>
<body>
    <H2> Writing PHP Function which returns value </H2>
<?php
     function printMe($param = NULL) {
       print $param;
     }
     printMe("This is Test");
     printMe();
     printMe("<br />This is Test");
     printMe();printMe();
   ?>
</body>
</html>