<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Passing Argument by Reference</title>
</head>
<body>
<?php
       function addFive($num) {
           $num += 5;
       }
       /* add & it means pass by reference */
       function addsix(&$num) {
           $num += 6;
       }
       $orignum = 10;
       addFive($orignum);
       echo "Original Value is {$orignum}<br />";
       addsix($orignum);
       echo "Original Value is {$orignum}<br />";
   ?>
</body>
</html>